from app_dojos_y_ninjas import app
from app_dojos_y_ninjas.controladores import controlador_dojos
if __name__=="__main__":
    app.run (debug=True)