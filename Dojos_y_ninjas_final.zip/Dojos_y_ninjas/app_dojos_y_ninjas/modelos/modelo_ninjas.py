from app_dojos_y_ninjas.config.mysqlconnection import connectToMySQL
from app_dojos_y_ninjas import BASE_DATOS

class Ninja:
    def __init__ (self, data):
        self.id = data['id']
        self.nombre=data['nombre']
        self.apellido=data['apellido']
        self.edad = data['edad']
        self.id_dojo=data['id_dojo']
        self.fecha_creacion = data['fecha_creacion']
        self.fecha_actualizacion = data['fecha_actualizacion'] 