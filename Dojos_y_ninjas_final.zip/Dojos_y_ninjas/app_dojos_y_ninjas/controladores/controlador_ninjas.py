from flask import render_template, request,redirect
from app_dojos_y_ninjas import app
@app.route('/formulario/ninja')
def desplegar_formulario_ninja():
    return render_template ('formulario_ninja.html')